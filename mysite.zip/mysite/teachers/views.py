# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import HttpResponse
from .forms import Profile_Form
from .models import User_Profile
import io,csv
# Create your views here.
import sys
reload(sys)
sys.setdefaultencoding('utf8')



def index(request):
    return render(request, 'error.html')#HttpResponse("Hello, world. You're at the polls index")
IMAGE_FILE_TYPES = ['csv']
def create_profile(request):
        form = Profile_Form()
        if request.method == 'POST':
            form = Profile_Form(request.POST, request.FILES)
            if form.is_valid():
                csv_file = request.FILES['display_picture']    # let's check if it is a csv file
                if not csv_file.name.endswith('.csv'):
                  return render(request, 'error.html')
                data_set = csv_file.read().decode('UTF-8')
                # setup a stream which is when we loop through each line we are able to handle a data in a stream
                io_string = io.StringIO(data_set)
                next(io_string)
                try:
                    for row in csv.reader(io_string, delimiter=str(",")):
                        x = row[6].split(", ")
                        if len(x)<6 :
                            UserProfile=User_Profile()
                            UserProfile.fname=row[0]
                            UserProfile.lname=row[1]
                            UserProfile.profilepicture=row[2]
                            UserProfile.email=row[3]
                            UserProfile.phone=row[4]
                            UserProfile.room=row[5]
                            UserProfile.technologies=row[6]
                            UserProfile.display_picture=request.FILES['display_picture']
                            UserProfile.save()
                except:
                    posts = User_Profile.objects.order_by('fname')
                    return render(request, 'details.html', {'user_pr': posts})
                
                posts = User_Profile.objects.order_by('fname')
    
                return render(request, 'details.html', {'user_pr': posts})
                    
                
                
                
        context = {"form": form,}
        return render(request, 'create.html', context)
        
def details(request):
         chosen_filter=""
         if request.method == 'POST':
            chosen_filter = request.POST.get('category-filter')
         if chosen_filter:
            posts = User_Profile.objects.order_by(chosen_filter)
         else:
            posts = User_Profile.objects.order_by('fname')
         return render(request, 'details.html', {'user_pr': posts})
                
        
