# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
class User_Profile(models.Model):
        fname = models.CharField(max_length=200)
        lname = models.CharField(max_length = 200)
        profilepicture= models.CharField(max_length = 500)
        phone = models.CharField(max_length=50,blank=True)
        room = models.CharField(max_length = 200)
        technologies = models.CharField(max_length=500)
        email = models.EmailField(blank=True,unique=True)
        display_picture = models.FileField()
        def __str__(self):
            return self.fname